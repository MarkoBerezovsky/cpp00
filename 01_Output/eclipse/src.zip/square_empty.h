#ifndef _SQUARE_EMPTY
#define  _SQUARE_EMPTY_

void square_empty(int a, int b);

#endif
