//============================================================================
// Name        : shapes.cpp
// Author      : mg
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "square_empty.h"
#include "shape_x.h"
using namespace std;
#include <iostream>
#include <string>

int getUserInputSelection();

int main() {

	int selection;
	string answer;

//	do {
//		cout<<" Hello, this program draws shapes."<<endl;
//		cout << " To continue type : yes" << endl;
//		cin >>  answer;
//
//	} while (answer.compare("yes") !=0 );

	do {
		selection = getUserInputSelection();
		if (selection == 1) {
			square_empty(8,5);
			//cout<<"1"<<endl;;
		}
		else if (selection ==2) {
			shape_x(int (9));
		}
		else if (selection == 3) {
			cout<<"goodbye";
		}

		else {
			cout<<"wrong selection";
		}

	} while (selection !=3);


	return 0;
}

int getUserInputSelection() {
	int selection;
	cout << "\nPlease select from the following menu:";
	cout << "\n   1. Draw empty square (a) ";
	cout << "\n   2. Draw square with X";
	cout << "\n   3. Exit the program";
	cout << "\n\nPlease input your selection: ";
	cin >> selection;

	return selection;
}
