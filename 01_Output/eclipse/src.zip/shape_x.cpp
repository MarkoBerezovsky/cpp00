/*
 * shape_x.cpp
 *
 *  Created on: Dec 15, 2016
 *      Author: porsche
 */

#include "shape_x.h"
#include <iostream>
using namespace std;

void printTwoAtPos (int pos,int len);
void printTopBottom (int size);
void printDiag (int size);

void shape_x(int size) {
	printTopBottom (size);
	cout<<endl;
	printDiag(size);
	printTopBottom (size);
	cout<<endl;
}


void printTopBottom (int size) {
	for (int i=1; i<=size; i++) {
		cout<<" #";
	}

}

void printDiag (int size) {
	for (int row=2; row<=size-1; row++) {

		printTwoAtPos (row,size);
		cout<<endl;
	}
}

void printTwoAtPos (int pos,int len) {
	for(int c=1;c<=len;c++) {
		if(c == pos || c== len-pos +1) {
			cout<<"# ";
			}
		else {
			cout <<"   ";
			}
		}
}




